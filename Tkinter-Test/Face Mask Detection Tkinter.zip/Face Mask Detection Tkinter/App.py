import tkinter
import cv2
import PIL.Image, PIL.ImageTk
import time

#import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model

# Load the model
model = load_model('model.h5')

# Define mediapipe Face detector
face_detection = mp.solutions.face_detection.FaceDetection()

class App:
    def __init__(self, window, window_title, video_source=0):
        self.window = window
        self.window.title(window_title)
        self.video_source = video_source
        
        # open video source (by default this will try to open the computer webcam)
        self.vid = MyVideoCapture(self.video_source)

        # Create a canvas that can fit the above video source size
        self.canvas = tkinter.Canvas(window, width = self.vid.width, height = self.vid.height)
        self.canvas.pack()

        # Button that lets the user take a snapshot
        self.btn_snapshot=tkinter.Button(window, text="Snapshot", width=50, command=self.snapshot)
        self.btn_snapshot.pack(anchor=tkinter.CENTER, expand=True)

        # After it is called once, the update method will be automatically called every delay milliseconds
        self.delay = 1
        self.update()
        self.window.mainloop()

    def snapshot(self):
        # Get a frame from the video source
        ret, frame = self.vid.get_frame_ori()
     
        if ret:
            cv2.imwrite("Snapshots/frame-" + time.strftime("%d-%m-%Y-%H-%M-%S") + ".jpg", cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
    
    def update(self):
        # Get a frame from the video source
        ret, frame = self.vid.get_frame()

        if ret:
            self.photo = PIL.ImageTk.PhotoImage(image = PIL.Image.fromarray(frame))
            self.canvas.create_image(0, 0, image = self.photo, anchor = tkinter.NW)
        else:
            image = PIL.Image.open("video_end.jpg")
            self.photo = PIL.ImageTk.PhotoImage(image = image)
            self.canvas.create_image(0, 0, image = self.photo, anchor = tkinter.NW)
        
        self.window.after(self.delay, self.update)

# Detection function
def get_detection(frame):
    height, width, channel = frame.shape

    # Convert frame BGR to RGB colorspace
    imgRGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Detect results from the frame
    result = face_detection.process(imgRGB)

    try:
        for count, detection in enumerate(result.detections):
            # print(detection)
            # Extract bounding box information 
            box = detection.location_data.relative_bounding_box
            x, y, w, h = int(box.xmin*width), int(box.ymin * height), int(box.width*width), int(box.height*height)
            
    # If detection is not available then pass 
    except:
        pass

    return x, y, w, h

def make_square(image):
    height, width = image.shape[0:2]
    size = max(height, width)

    #Creating a dark square with NUMPY
    frame = np.zeros((size, size, 3), np.uint8)

    #Getting the centering position
    center_x, center_y = (size - width)//2, (size - height)//2

    #Pasting the 'image' in a centering position
    frame[center_y:height+center_y, center_x:center_x+width] = image

    return frame

def detectionframe(x):
    CATEGORIES = ['no_mask', 'mask']
    frame = x
    img = frame.copy()

    try:
        x, y, w, h = get_detection(frame)
        crop_img = img[y:y+h, x:x+w]
        crop_img = cv2.resize(crop_img, (100, 100))
        crop_img = np.expand_dims(crop_img, axis=0)
        
        # get the prediction from the model.
        prediction = model.predict(crop_img)
        print(prediction)
        index = np.argmax(prediction)
        res = CATEGORIES[index]

        if index == 0:
            color = (0, 0, 255)
        else:
            color = (0, 255, 0)
        
        # put labels
        frame = cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        frame = cv2.putText(frame, res, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2, cv2.LINE_AA)

        # add black background
        frame = make_square(frame)

        #resize
        frame = cv2.resize(frame, (500, 500), interpolation= cv2.INTER_LINEAR)

        return frame

    except Exception as error:
        print(error)

class MyVideoCapture:
    def __init__(self, video_source=0):
        # Open the video source
        self.vid = cv2.VideoCapture(video_source)
        if not self.vid.isOpened():
            raise ValueError("Unable to open video source", video_source)
        
        self.width = 500
        self.height = 500
    
    def get_frame(self):
        if self.vid.isOpened():
            try:
                ret, frame = self.vid.read()
                if ret:
                    frame = detectionframe(frame)
                    # Return a boolean success flag and the current frame converted to BGR
                    return (ret, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                else:
                    return (None, None)
            except:
                return (None, None)
        else:
            return (None, None)
    
    def get_frame_ori(self):
        if self.vid.isOpened():
            ret, frame = self.vid.read()
            if ret:
                # Return a boolean success flag and the current frame converted to BGR
                return (ret, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            else:
                return (None, None)
        else:
            return (None, None)
    
    # Release the video source when the object is destroyed
    def __del__(self):
        if self.vid.isOpened():
            self.vid.release()


class ImageApp:
    def __init__(self, window, window_title, image_source=None):
        self.window = window
        self.window.title(window_title)
        self.image_source = image_source
        
        # open video source (by default this will try to open the computer webcam)
        self.img = ImageCapture(self.image_source)

        # Create a canvas that can fit the above video source size
        self.canvas = tkinter.Canvas(window, width = self.img.width, height = self.img.height)
        self.canvas.pack()

        # Button that lets the user take a snapshot
        self.btn_exit=tkinter.Button(window, text="Exit", width=50, command=window.destroy)
        self.btn_exit.pack(anchor=tkinter.CENTER, expand=True)

        self.update()

        self.window.mainloop()
    
    def update(self):
        # Get a frame from the video source
        ret, frame = self.img.get_frame()

        if ret:
            self.photo = PIL.ImageTk.PhotoImage(image = PIL.Image.fromarray(frame))
            self.canvas.create_image(0, 0, image = self.photo, anchor = tkinter.NW)
        else:
            self.photo = PIL.ImageTk.PhotoImage(image = PIL.Image.open("video_end.jpg"))
            self.canvas.create_image(0, 0, image = self.photo, anchor = tkinter.NW)

class ImageCapture:
    def __init__(self, image_source=None):
        # Open the video source
        self.frame = cv2.imread(image_source)
        self.width = 500
        self.height = 500
    
    def get_frame(self):
        try:
            frame = detectionframe(self.frame)
            # Return a boolean success flag and the current frame converted to BGR
            return 1, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        except:
             return None, None
        

# Create a window and pass it to the Application object
App(tkinter.Tk(), "Tkinter and OpenCV", "test.mp4")
#ImageApp(tkinter.Tk(), "Tkinter and OpenCV", "test.jpg")